/**
 * Lead Author(s):
 * @author Beatrice
 * 
 * 
 *  
 * Version/date: ver.001
 * 
 * Responsibilities of class: 
 * 
 */
/**
 */
public class Inventory {

}
