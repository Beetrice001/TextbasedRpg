
public class Player extends Character {
	private String playerClass;

	public Player(String name, String playerClass, int health, int stamina, int mana, int strength, int agility,
			int intelligence, int endurance, int luck) {
		super(name, health, stamina, mana, strength, agility, intelligence, endurance, luck);
		this.playerClass = playerClass;
	}

	@Override
	public void attack(Character target) {
		System.out.printf("placeholder", this.name, target.name);
		// method here 
	}

	@Override
	public void defend() {
		System.out.printf("placeholder", this.name);
		// method here
	}

	@Override
	public String toString() {
		//method here
	}
}