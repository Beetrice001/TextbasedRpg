
public class GameScenario {

}
