/**
 * Lead Author(s):
 * @author Beatrice
 * 
 * 
 *  
 * Version/date: ver.001
 * 
 * Responsibilities of class: 
 * 
 */
/**
 */
public class Enemy extends Character {
    private String weakness;

    public Enemy(String name, int health, int stamina, int mana, int strength, int agility, int intelligence, int endurance, int luck, String weakness) {
        super(name, health, stamina, mana, strength, agility, intelligence, endurance, luck);
        this.weakness = weakness;
    }

    @Override
    public void attack(Character target) {
        System.out.printf("placholder", this.name, target.name);
        // method
    }

    @Override
    public void defend() {
        System.out.printf("placeholder", this.name);
        // mehtod
    }

    @Override
    public String toString() {
    	//methpd
    }
    }