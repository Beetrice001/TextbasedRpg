import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JFrame {
    private JTextArea scenarioTextArea;
    private JButton attackButton;
    private JButton defendButton;
    private JLabel healthLabel;
    private JLabel staminaLabel;
    private JLabel manaLabel;
    
    private Player player;
    private Enemy enemy;
    
}

