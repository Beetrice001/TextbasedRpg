/**
 * Lead Author(s):
 * @author Beatrice
 * 
 * 
 *  
 * Version/date: ver.001
 * 
 * Responsibilities of class: Defines base traits of characters
 * 
 */
/**
 */
public abstract class Character {
	private String name;
	private int strength;
	private int agility;
	private int endurance;
	private int intelligence;
	private int luck;
	private int health;
	private int stamina;
	private int mana;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public int getAgility() {
		return agility;
	}

	public void setAgility(int agility) {
		this.agility = agility;
	}

	public int getEndurance() {
		return endurance;
	}

	public void setEndurance(int endurance) {
		this.endurance = endurance;
	}

	public int getIntelligence() {
		return intelligence;
	}

	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}

	public int getLuck() {
		return luck;
	}

	public void setLuck(int luck) {
		this.luck = luck;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public int getStamina() {
		return stamina;
	}

	public void setStamina(int stamina) {
		this.stamina = stamina;
	}

	public int getMana() {
		return mana;
	}

	public void setMana(int mana) {
		this.mana = mana;
	}

	public boolean isAlive() {
		return health > 0;
	}

	public void takeDamage(int damage) {
		this.health -= damage;
		if (this.health < 0) {
			this.health = 0;
		}
	}

	public abstract void attack(Character target);
	
	public abstract void defend();

	@Override
	public String toString() {
		// write toString method here
	}

//Abstract methods to be implemented in subclasses
	
}
